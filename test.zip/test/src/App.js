import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import React from 'react';
import axios from 'axios';
function App() {
  const Base = 'http://3.109.141.224:5000/'
  
  const [userToken, setUserToken] = useState('');
  const [text, setText] = useState('');
  const [searchData, setSearchData] = useState([])
  
  useEffect(()=>{
    token() 
  },[])

  const token = async ()=>{
    await axios.get(Base+'api/user-access-token')
    .then((response)=>{
      const accessToken = response.data.token
     setUserToken(accessToken);
    })
    .catch(error=>console.log(error))
  } 
  const onSearchHandle = async() => {
    const route = Base+'api/'+ `${userToken}`
    console.log(route)
    await axios.get(Base+'api/'+ `data?search_string=${text}`,{headers:{
      'user-access-token':userToken
    }})
    .then((response)=>{
      const searchValue = response.data
      console.log(searchValue)
       setSearchData(searchValue);
    })
    .catch(error=>console.log(error))
  }
  return (

    <div className="App">
    <input
    onChange={(e)=>setText(e.target.value)}
    >

    </input>
    <button
    onClick={
      onSearchHandle
    }
    >
      search
    </button>
    <div>
      {searchData.map((item)=>{
        item.map((stock)=>{
          return <div>
            Name:{stock[0]}
            Price:{stock[1]}
            SellPrice{stock[2]}
          </div>
        })
      })}
    </div>
    </div>
    
  );
}

export default App;
